export const token =
  "4"; //ds token
export const avatarLink =
  "5"; //webhook avatar

export const tgBotToken = "7"; //tg bot token(api)

export const tgcallsId = "9"; //канал в тг с колами


//массив каналов, чтобы добавлять новые каналы необходимо создать новый объект в массиве(с фигурными скобками {}, )
export const mirror = [
  {
    channelName: "0", //название канала(отображается)
    id1: "8", //айди канала откуда берется информация
    wh: "6", //вебхук канала куда поступает информация
    id2: "3", //айди канала-буфера откуда идет отправка в телеграмм
  },
];
