import selfcore from "selfcore";
import TelegramBot from "node-telegram-bot-api";

import {
  tgBotToken,
  token,
  tgcallsId,
  avatarLink,
  mirror,
} from "./config.js";

const client = new selfcore();
// const gateway = new selfcore.Gateway(TOKEN);
const bot = new TelegramBot(tgBotToken, { polling: true });

const gatewayTOKEN = new selfcore.Gateway(token);


gatewayTOKEN.on("message", (msg) => {
  let userMsg = { embeds: [msg.embeds[0]] };
  let userImg = { attachments: [msg.attachments[0]] };

  const username = msg.author.username;

  let content = msg.content ? msg.content : userMsg;
  let urlContent = userImg ? userImg : msg.userImg;

  function arr_list(i) {
    if (msg.channel_id === i.id1) {
      if (msg.content) {
        client.sendWebhook(i.wh, {
          username: `${username}`,
          avatar_url: `${avatarLink}`,
          content: `${content}`,
          embeds: [],
          components: [],
        });
      } else {
        if (msg.attachments.length < 1) {
          console.log(msg);
          return;
        } else {
          client.sendWebhook(i.wh, {
            username: `${username}`,
            avatar_url: `${avatarLink}`,
            content: `${urlContent.attachments[0].url}`,
            embeds: [],
            components: [],
          });
        }
      }
    } else if (msg.channel_id === i.id2) {
      if (msg.content) {
        bot.sendMessage(
          tgcallsId,
          `${i.channelName}:
        🗣${username}:
        ${content}`
        );
      } else {
        if (msg.attachments.length < 1) {
          console.log(msg);
          return;
        } else {
          bot.sendMessage(
            tgcallsId,
            i.channelName,
            username,
            urlContent.attachments[0].url
          );
        }
      }
    }
  }
  mirror.forEach(arr_list);
});
